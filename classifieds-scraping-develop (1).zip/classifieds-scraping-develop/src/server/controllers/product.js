const productDataService = require('../api/scrap/scrap');

exports.getAllProducts = async (req, res, next) => {
  const theCategory = 'appartements';
  const websiteURL = 'https://www.avito.ma/fr/maroc/';
  let mydata = [];

  /*mydata=[
    {
        "desc": "Appartement 90 m2 en Location à Casablanca",
        "price": "5 000",
        "image": "https://www.avito.ma/images/88/8807703139.jpg"
    },
    {
        "desc": "Abdeljebar",
        "price": "1 100 000",
        "image": "https://www.avito.ma/images/77/7742967434.jpg"
    },
    {
        "desc": "Prestige Appartement",
        "price": "5 500",
        "image": "https://www.avito.ma/images/88/8858142916.jpg"
    },
    {
        "desc": "Location appartement à sala aljadida",
        "price": "",
        "image": ""
    },
    {
        "desc": "Appartement de 90 m²",
        "price": "250",
        "image": "https://www.avito.ma/images/88/8818893991.jpg"
    },
    {
        "desc": "Appartement Haut-Fount ACOTE DE AGADIR BAY 148M2",
        "price": "1 036 000",
        "image": "https://www.avito.ma/images/03/0330239453.jpg"
    },
    {
        "desc": "appartement Allouer ain aouda",
        "price": "1 600",
        "image": "https://www.avito.ma/images/88/8890239925.jpg"
    },
    {
        "desc": "Appartement en Location (Par Mois) à Meknès",
        "price": "2 500",
        "image": "https://www.avito.ma/images/88/8805110879.jpg"
    },
    {
        "desc": "appartement a centre-ville settat",
        "price": "520 000",
        "image": "https://www.avito.ma/images/66/6641743939.jpg"
    },
    {
        "desc": "Appartement en Vente à Bouznika",
        "price": "360 000",
        "image": "https://www.avito.ma/images/88/8886276262.jpg"
    },
    {
        "desc": "appartement à louer 1chambre1salon sdb",
        "price": "1 800",
        "image": ""
    },
    {
        "desc": "Appartement en Location à Casablanca",
        "price": "3 500",
        "image": "https://www.avito.ma/images/88/8870525754.jpg"
    },
    {
        "desc": "Appartement à Mohammedia Riad Chellalat",
        "price": "310 000",
        "image": "https://www.avito.ma/images/88/8886768111.jpg"
    },
    {
        "desc": "Studio à louer vide",
        "price": "2 400",
        "image": "https://www.avito.ma/images/88/8819669401.jpg"
    },
    {
        "desc": "Appartement de red chausse",
        "price": "550 000",
        "image": "https://www.avito.ma/images/83/8301514630.jpg"
    },
    {
        "desc": "Appartement meublé à louer sur Hay Riad",
        "price": "19 000",
        "image": "https://www.avito.ma/images/07/0755506928.jpg"
    },
    {
        "desc": "Appartement 79 m2 en Ve à Agadir",
        "price": "",
        "image": "https://www.avito.ma/images/66/6691620762.jpg"
    },
    {
        "desc": "appartement 102 m a prestigia",
        "price": "7 500",
        "image": "https://www.avito.ma/images/88/8829592994.jpg"
    },
    {
        "desc": "شقة 2غرف 70 م2 تطل على شاطئ سيدي رحال تسليم فوري",
        "price": "",
        "image": "https://www.avito.ma/images/84/8447721527.jpg"
    },
    {
        "desc": "برطمة 78 م2 بسيدي رحال الشاطئ مع تسليم فوري",
        "price": "",
        "image": "https://www.avito.ma/images/84/8499486305.jpg"
    },
    {
        "desc": "برطمة 56 م2 بشاطئ سيدي رحال مع تسليم فوري",
        "price": "",
        "image": "https://www.avito.ma/images/84/8456869710.jpg"
    },
    {
        "desc": "Appartement en Location (Par Mois) à Berrechid",
        "price": "",
        "image": "https://www.avito.ma/images/88/8836507751.jpg"
    },
    {
        "desc": "apparemment à vendre hay hiba wad fes",
        "price": "370 000",
        "image": ""
    },
    {
        "desc": "Appartement standing",
        "price": "1 000 000",
        "image": ""
    },
    {
        "desc": "Bel Appartement moderne 70m² meuble neuf",
        "price": "6 000",
        "image": "https://www.avito.ma/images/08/0889417982.jpg"
    },
    {
        "desc": "bien équipé à louer meublé",
        "price": "4 500",
        "image": "https://www.avito.ma/images/88/8848502884.jpg"
    },
    {
        "desc": "Apparemment avendre neuf proche de la plage",
        "price": "380 000",
        "image": "https://www.avito.ma/images/41/4168404488.jpg"
    },
    {
        "desc": "Appartement 100 m2 a najah",
        "price": "3 700",
        "image": "https://www.avito.ma/images/74/7469099217.jpg"
    },
    {
        "desc": "APPARTEMENT À LOUER ENCG",
        "price": "4 000",
        "image": "https://www.avito.ma/images/87/8797253738.jpg"
    },
    {
        "desc": "Location appartement 3pièces salon hay el fath",
        "price": "3 500",
        "image": "https://www.avito.ma/images/68/6846145694.jpg"
    },
    {
        "desc": "Meilleur service chez serraj immobilier",
        "price": "",
        "image": "https://www.avito.ma/images/88/8892525944.jpg"
    },
    {
        "desc": "bel Appartement 120m2 a la marina",
        "price": "8 000",
        "image": "https://www.avito.ma/images/39/3911866678.jpg"
    },
    {
        "desc": "Très beau Appartement rez de chausse",
        "price": "",
        "image": "https://www.avito.ma/images/88/8813709471.jpg"
    },
    {
        "desc": "Appartement de 87 m2 à Marrakech",
        "price": "5 500",
        "image": "https://www.avito.ma/images/69/6929148523.jpg"
    },
    {
        "desc": "Appartements neuf avendr à saidia",
        "price": "300 000",
        "image": "https://www.avito.ma/images/25/2546351639.jpg"
    }
]*/

  mydata = await productDataService.fetchProductList(websiteURL, theCategory);
  res.json(mydata);
};